package personal.alex.workoutapp.viewmodels;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import personal.alex.workoutapp.models.Routine;

public class MainActivityViewModel {

    private MutableLiveData<List<Routine>> mRoutine;

    public LiveData<List<Routine>> getRoutines(){
        return mRoutine;
    }
}
