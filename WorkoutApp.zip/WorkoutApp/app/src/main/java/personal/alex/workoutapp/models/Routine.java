package personal.alex.workoutapp.models;

public class Routine {
}
